# Team XX — Visualization

- ผู้ใช้ที่เลือก (≥ 2 กลุ่ม, มีผู้ใช้หน้างาน ≥ 1): เช่น คนขับ/Vendor + ผู้บริหาร
- ไฟล์ / ลิงก์: เช่น `driver_view.html`, `exec_onepage.pdf`, หรือ URL ของ Power BI / Streamlit
- วิธีเปิด: ...
- ข้อมูลที่ใช้: `out/day1/plan_loads.csv`, `plan_result.json` (จาก evaluate.py)
- ทำไมดีกว่าหน้าจอเดิม (1–3 บรรทัด):
