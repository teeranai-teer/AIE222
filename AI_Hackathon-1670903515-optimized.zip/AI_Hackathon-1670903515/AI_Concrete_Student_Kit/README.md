# AI Concrete — Student Kit
**AI Hackathon Route Optimization 2026 · AI for Green Logistics**

คุณคือทีมวางแผนจัดส่งของ **AI Concrete** (บริษัทคอนกรีตผสมเสร็จสมมติ) ในเมือง **เมโทรซิตี้**
ทุกเที่ยวรถโม่ของวันพรุ่งนี้: **โหลดที่โรงงานไหน · ใช้รถคันไหน · เริ่มโหลดกี่โมง** — ให้ SLA ลูกค้าทุก Grade ผ่าน แล้วได้ **Contribution สูงสุด**
ทดสอบ **5 วันที่เหตุการณ์ต่างกัน**: แจก Day 1–4 · **Day 5 เป็นวันลับ** ผู้จัดรัน `solve.py` ของทีมเอง

> ข้อมูลทั้งหมดเป็น **ข้อมูลจำลอง** ไม่ใช่ข้อมูลลูกค้าหรือตัวเลขจริงของบริษัทใด

## อ่านก่อน
| ไฟล์ | คืออะไร |
|---|---|
| `AI_Concrete_DataBook.pdf` (หรือ `.html`) | คู่มือ A4 19 หน้า: โจทย์ กติกา พจนานุกรมข้อมูลทุกไฟล์ เรื่องราวของแต่ละวัน การให้คะแนน |
| `data_viewer.html` | ตารางข้อมูลแต่ละวัน (SLA ราย Grade, ลูกค้า/Value, เหตุการณ์, ออเดอร์) และลากผลของทีมมาเทียบตัวเลข — **ไม่มีกราฟ: กราฟเป็นโจทย์ Visualization ของทีม** |

## เริ่มใน 5 นาที
```bash
cd starter
python evaluate.py ../data/day1_weekday ../data/day1_weekday/planner_plan.csv     # แผนของพนักงาน
python solve.py ../data/day1_weekday ../out/day1                                   # โค้ดตัวอย่าง Level 1
python evaluate.py ../data/day1_weekday ../out/day1/plan.csv --changes ../out/day1/order_changes.csv --production ../out/day1/production_plan.csv
```
Python 3.9+ ไม่ต้องติดตั้งอะไรเพิ่ม · `starter.ipynb` ใช้ pandas + matplotlib · `evaluate.py` เขียน `plan_loads.csv` และ `plan_result.json` ไว้ลากเข้า data_viewer และใช้ทำ visualization

## ข้อมูล
```
data/common/              ใช้ทุกวัน: plants, products, plant_product_cost, sites, customers, routes, speed_limits,
                          traffic_periods, trucks, cost_params, plant_load_history, production_notes
data/day1_weekday/        วันทำงานปกติ (งานโครงการ 10:00 · คนขับลาป่วย)
data/day2_school_opening/ วันเปิดภาคเรียน (เขตโรงเรียน ห้ามรถบรรทุกช่วงรับส่ง · รถติดเช้า)
data/day3_festival/       วันลอยกระทง (รถติดบ่าย · ปิดถนนเขตกลางเมืองตั้งแต่ 17:00)
data/day4_holiday/        วันหยุด (ถนนโล่ง · คนขับลา 35% · โรงงานปิด/ลดไลน์)
  แต่ละวัน: day_info, planner_orders, planner_plan, traffic_events, plant_status, trucks_today
```
รายละเอียดทุกคอลัมน์อยู่ใน Data Book หน้า 3–12

## กติกาโดยย่อ (ตัวจำลอง `starter/aiconcrete.py` คือกติกาจริง)
- ไลน์ผลิตไม่ว่างช่วง เตรียมสูตร + ผสม · QC ที่โรงงานก่อนออก · อายุคอนกรีตนับจาก load_start (120 / 150 นาทีสำหรับสูตรหน่วง)
- เวลาเดินทางตามช่วงที่ออกรถ × ตัวคูณเหตุการณ์ของวัน · ห้ามเข้า/ปิดถนน = รอ · หน่วยงานเททีละคันตาม seq
- ขอลูกค้าเลื่อนได้เฉพาะรายที่มี flex_type · เพิ่มไลน์ได้เฉพาะโรงงานที่มี boost_* · ใช้เฉพาะรถที่มาทำงาน

## ส่งงาน (โฟลเดอร์ `teamXX/` ดูตัวอย่างใน `submission_example/teamXX/`)
```
teamXX/
  out/day1/plan.csv  order_changes.csv  production_plan.csv   ... out/day4/
  code/solve.py  (+ ไฟล์ของทีม, requirements.txt)
  viz/  (+ viz/README.md)
  APPROACH.md
```
**วันลับ**: ผู้จัดรัน `python solve.py <day5_dir> <out_dir>` ในโฟลเดอร์ `code/` · ไม่มีอินเทอร์เน็ต · ภายใน 5 นาที

## อันดับ
1. จำนวนวันที่ผ่าน SLA (จาก 5) → 2. Contribution รวม 5 วัน → 3. ระยะทางรวมน้อยกว่า
รอบคัดเลือก: ผลอัตโนมัติ 60 + แนวทาง 40 · รอบบ่าย 15 ทีม: ผลอัตโนมัติ 50 + แนวทาง 30 + **Visualization/UX 20**

## Visualization Challenge
ออกแบบหน้าจอ/ภาพสื่อสารแผนของทีมให้คนใน E2E Supply Chain (ผู้บริหาร · Dispatcher · โรงงาน · คนขับ · ฝ่ายขาย · ลูกค้า) —
เลือก ≥ 2 กลุ่ม มีผู้ใช้หน้างาน ≥ 1 · รูปแบบอะไรก็ได้ · ส่งรุ่นแรกก่อน 3:00 ทีมที่เข้ารอบแก้ต่อได้ช่วงพักกลางวัน ·
กรรมการทดสอบด้วยคำถามจริงจับเวลาเทียบหน้าจอเดิมของบริษัท (Data Book หน้า 18)

> **คำใบ้**: ข้อมูลในระบบไม่ได้ถูกต้องทุกช่อง และบางวันแก้ด้วยโค้ดอย่างเดียวไม่ได้ — อ่านทุกไฟล์ให้ครบ
